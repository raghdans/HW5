from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

from src.utils import RESULTS_DIR, hardware_summary, write_failure, write_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Verify a basic local Ollama generation.")
    parser.add_argument("--model", default="tinyllama")
    parser.add_argument("--prompt", default="Explain in one sentence what LLM inference is.")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--ollama-exe", default=None, help="Optional path to a portable ollama executable.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    executable = args.ollama_exe or shutil.which("ollama")
    if executable is None or not Path(executable).exists():
        message = "Ollama executable was not found. Install Ollama and rerun this command."
        write_failure("ollama", message, {"model": args.model})
        print(message, file=sys.stderr)
        return 2

    start = time.perf_counter()
    try:
        completed = subprocess.run(
            [executable, "run", "--nowordwrap", args.model, args.prompt],
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=args.timeout,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        message = f"Ollama run failed: {type(exc).__name__}: {exc}"
        write_failure("ollama", message, {"model": args.model, "hardware": hardware_summary()})
        print(message, file=sys.stderr)
        return 2

    payload = {
        "experiment": "ollama",
        "status": "ok",
        "model_id": args.model,
        "prompt": args.prompt,
        "generated_text": completed.stdout.strip(),
        "total_runtime_seconds": time.perf_counter() - start,
        "hardware": hardware_summary(),
    }
    write_json(RESULTS_DIR / "ollama.json", payload)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
