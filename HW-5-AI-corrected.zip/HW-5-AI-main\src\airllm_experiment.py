from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

if __package__ is None or __package__ == "":
    sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.utils import (
    BenchmarkResult,
    MemoryMonitor,
    hardware_summary,
    load_prompts,
    write_failure,
    write_results,
)


DEFAULT_LARGE_MODEL = "Qwen/Qwen2.5-7B-Instruct"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a real layer-streamed AirLLM benchmark.")
    parser.add_argument("--model", default=DEFAULT_LARGE_MODEL)
    parser.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    parser.add_argument("--max-new-tokens", type=int, default=16)
    parser.add_argument("--max-input-tokens", type=int, default=128)
    parser.add_argument("--prompts", default=None)
    parser.add_argument("--layer-cache", default=None, help="Directory for AirLLM's layer-wise model shards.")
    parser.add_argument("--compression", choices=["4bit", "8bit"], default=None)
    parser.add_argument("--output-name", default="airllm")
    return parser.parse_args()


def resolve_device(torch, requested: str) -> str:
    if requested == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available.")
    return requested


def prompt_text(tokenizer, prompt: str) -> str:
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(
            [{"role": "user", "content": prompt}], tokenize=False, add_generation_prompt=True
        )
    return prompt


def benchmark_one(model, torch, model_id: str, device: str, prompt_row: dict, args) -> BenchmarkResult:
    text = prompt_text(model.tokenizer, prompt_row["prompt"])
    tokens = model.tokenizer(
        [text],
        return_tensors="pt",
        return_attention_mask=False,
        truncation=True,
        max_length=args.max_input_tokens,
        padding=False,
    )
    input_ids = tokens["input_ids"].to(device)
    input_count = int(input_ids.shape[-1])

    # AirLLM does not expose a token streamer. A one-token generation is the
    # closest reproducible TTFT measurement; the full run is measured separately.
    first_start = time.perf_counter()
    with torch.inference_mode():
        model.generate(input_ids, max_new_tokens=1, use_cache=True, return_dict_in_generate=True)
    ttft = time.perf_counter() - first_start

    if device == "cuda":
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
    start = time.perf_counter()
    with MemoryMonitor() as monitor:
        with torch.inference_mode():
            output = model.generate(
                input_ids,
                max_new_tokens=args.max_new_tokens,
                use_cache=True,
                return_dict_in_generate=True,
            )
    runtime = time.perf_counter() - start

    sequence = output.sequences[0]
    new_ids = sequence[input_count:]
    output_count = int(new_ids.numel())
    generated_text = model.tokenizer.decode(new_ids, skip_special_tokens=True).strip()
    # The TTFT probe and full generation are separate AirLLM calls. Subtracting
    # one from the other would mix cache states, so TPOT is intentionally absent.
    tpot = None
    throughput = output_count / runtime if runtime > 0 and output_count else None

    return BenchmarkResult(
        experiment="airllm",
        model_id=model_id,
        prompt_id=prompt_row["id"],
        prompt_chars=len(prompt_row["prompt"]),
        input_tokens=input_count,
        output_tokens=output_count,
        ttft_seconds=ttft,
        tpot_seconds=tpot,
        throughput_tokens_per_second=throughput,
        peak_ram_mb=monitor.peak_ram_mb,
        peak_vram_mb=monitor.peak_vram_mb,
        total_runtime_seconds=runtime,
        device=device,
        dtype="airllm-layer-streaming",
        status="ok",
        error="",
        generated_text=generated_text,
        quality_notes="Manual review required. TTFT is a separate one-token run; TPOT is not reported.",
    )


def main() -> int:
    args = parse_args()
    metadata = {"model": args.model, "hardware": hardware_summary(), "requested_device": args.device}
    try:
        import torch
        from airllm import AutoModel

        device = resolve_device(torch, args.device)
        # AirLLM defaults its internal layer runner to cuda:0. Passing the
        # device here is essential; moving only input_ids does not select CPU.
        kwargs = {"profiling_mode": True, "device": device}
        if args.layer_cache:
            kwargs["layer_shards_saving_path"] = args.layer_cache
        if args.compression:
            kwargs["compression"] = args.compression
        model = AutoModel.from_pretrained(args.model, **kwargs)
        prompts = load_prompts(Path(args.prompts)) if args.prompts else load_prompts()
        rows = [benchmark_one(model, torch, args.model, device, row, args) for row in prompts]
    except Exception as exc:
        message = f"AirLLM run failed: {type(exc).__name__}: {exc}"
        write_failure(args.output_name, message, metadata)
        print(message, file=sys.stderr)
        return 2

    json_path, csv_path = write_results(args.output_name, rows)
    print(f"Wrote {json_path}\nWrote {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
