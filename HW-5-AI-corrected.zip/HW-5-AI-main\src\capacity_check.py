from __future__ import annotations

import argparse
import json

from src.utils import RESULTS_DIR, hardware_summary, write_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Document whether an unquantized model safely fits in RAM/VRAM.")
    parser.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct")
    parser.add_argument("--parameters-billions", type=float, default=7.62)
    parser.add_argument("--bytes-per-parameter", type=float, default=4.0, help="FP32 baseline storage per weight.")
    parser.add_argument("--runtime-overhead", type=float, default=1.20, help="Weights-only estimate multiplier.")
    parser.add_argument("--available-ram-gb", type=float, default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    hardware = hardware_summary()
    available = args.available_ram_gb
    if available is None:
        try:
            import psutil

            available = psutil.virtual_memory().available / (1024**3)
        except Exception:
            available = None

    weights_gb = args.parameters_billions * 1_000_000_000 * args.bytes_per_parameter / (1024**3)
    estimated_peak_gb = weights_gb * args.runtime_overhead
    fits = None if available is None else estimated_peak_gb <= available
    payload = {
        "experiment": "large_model_capacity_check",
        "status": "ok",
        "model_id": args.model,
        "parameters_billions": args.parameters_billions,
        "baseline_dtype": "float32",
        "estimated_weights_gb": round(weights_gb, 2),
        "estimated_peak_ram_gb": round(estimated_peak_gb, 2),
        "available_ram_gb_at_check": None if available is None else round(available, 2),
        "baseline_safe_to_attempt": fits,
        "conclusion": (
            "The unquantized baseline is predicted not to fit; do not force an OOM merely to prove it."
            if fits is False
            else "Capacity estimate does not prove failure; run the baseline to measure it."
        ),
        "method": "parameter_count * bytes_per_parameter * runtime_overhead",
        "hardware": hardware,
    }
    write_json(RESULTS_DIR / "large_model_capacity_check.json", payload)
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
