"""Benchmark utilities for EX05 AirLLM and quantization assignment."""
