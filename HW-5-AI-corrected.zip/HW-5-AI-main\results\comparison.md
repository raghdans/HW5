| experiment | model_id | status | device | ttft_s | tpot_s | tokens_s | ram_mb | vram_mb | runtime_s | note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| cpu_baseline | TinyLlama/TinyLlama-1.1B-Chat-v1.0 | ok | cpu | 1.0909 | 0.2323 | 3.5013 | 4596.276 |  | 4.5752 |  |
| gpu_baseline | Qwen/Qwen2.5-7B-Instruct | failed |  |  |  |  |  |  |  | gpu_baseline could not run: RuntimeError: CUDA was explicitly requested but is not available. |
| airllm | Qwen/Qwen2.5-7B-Instruct | ok | cpu | 24.4989 |  | 0.0507 | 1427.332 |  | 39.4599 |  |
