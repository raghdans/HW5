from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from transformers.generation.streamers import BaseStreamer

if __package__ is None or __package__ == "":
    sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.utils import (
    BenchmarkResult,
    MemoryMonitor,
    git_commit,
    hardware_summary,
    load_prompts,
    write_failure,
    write_results,
)


DEFAULT_MODEL = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"


class TokenTimingStreamer(BaseStreamer):
    """Record generated-token arrival times without buffering decoded text.

    Transformers first sends the prompt IDs to a streamer and then sends newly
    generated IDs. Timing token IDs avoids the word/chunk buffering performed by
    TextIteratorStreamer, which otherwise overestimates TTFT.
    """

    def __init__(self) -> None:
        self._saw_prompt = False
        self.token_times: list[float] = []

    def put(self, value) -> None:  # transformers' streamer protocol
        if not self._saw_prompt:
            self._saw_prompt = True
            return
        count = int(value.numel()) if hasattr(value, "numel") else 1
        now = time.perf_counter()
        self.token_times.extend([now] * max(count, 1))

    def end(self) -> None:
        return None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Benchmark a Hugging Face causal LM.")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--experiment", choices=["baseline", "fp16", "int8", "int4"], default="baseline")
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument("--output-name", default=None, help="Result basename, e.g. cpu_baseline or gpu_baseline.")
    parser.add_argument("--max-new-tokens", type=int, default=64)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--prompts", default=None)
    return parser.parse_args()


def resolve_device(requested: str) -> str:
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was explicitly requested but is not available.")
    if requested == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    return requested


def model_kwargs_for_experiment(experiment: str, device: str) -> tuple[dict, str]:
    if experiment == "baseline":
        if device == "cuda":
            return {"device_map": "cuda", "torch_dtype": "auto"}, "auto"
        return {"torch_dtype": torch.float32}, "float32"
    if experiment == "fp16":
        if device != "cuda":
            raise RuntimeError("FP16 acceleration requires a CUDA device in this experiment.")
        return {"device_map": "cuda", "torch_dtype": torch.float16}, "float16"
    if experiment in {"int8", "int4"}:
        if device != "cuda":
            raise RuntimeError(f"{experiment} bitsandbytes quantization requires CUDA in this project.")
        try:
            import bitsandbytes  # noqa: F401
        except Exception as exc:
            raise RuntimeError(f"bitsandbytes is not available: {exc}") from exc
        if experiment == "int8":
            return {"device_map": "cuda", "quantization_config": BitsAndBytesConfig(load_in_8bit=True)}, "int8-bnb"
        config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.float16)
        return {"device_map": "cuda", "quantization_config": config}, "int4-bnb"
    raise ValueError(experiment)


def apply_chat_template(tokenizer, prompt: str) -> str:
    messages = [{"role": "user", "content": prompt}]
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    return prompt


def benchmark_prompt(model, tokenizer, model_id: str, experiment: str, dtype: str, device: str, prompt_row: dict, args) -> BenchmarkResult:
    prompt = apply_chat_template(tokenizer, prompt_row["prompt"])
    encoded = tokenizer(prompt, return_tensors="pt")
    input_tokens = int(encoded.input_ids.shape[-1])
    encoded = {key: value.to(device) for key, value in encoded.items()}

    if device == "cuda":
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()

    streamer = TokenTimingStreamer()
    generation_kwargs = {
        **encoded,
        "streamer": streamer,
        "max_new_tokens": args.max_new_tokens,
        "do_sample": args.temperature > 0,
        "temperature": args.temperature if args.temperature > 0 else None,
        "pad_token_id": tokenizer.eos_token_id,
    }
    generation_kwargs = {key: value for key, value in generation_kwargs.items() if value is not None}

    start = time.perf_counter()
    with MemoryMonitor() as monitor:
        with torch.inference_mode():
            generated = model.generate(**generation_kwargs)
    end = time.perf_counter()

    new_ids = generated[0, input_tokens:]
    output_tokens = int(new_ids.numel())
    generated_text = tokenizer.decode(new_ids, skip_special_tokens=True).strip()
    total_runtime = end - start
    ttft = streamer.token_times[0] - start if streamer.token_times else None
    tpot = None
    if ttft is not None and output_tokens > 1:
        tpot = max(total_runtime - ttft, 0.0) / (output_tokens - 1)
    throughput = output_tokens / total_runtime if total_runtime > 0 and output_tokens else None

    return BenchmarkResult(
        experiment=experiment,
        model_id=model_id,
        prompt_id=prompt_row["id"],
        prompt_chars=len(prompt_row["prompt"]),
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        ttft_seconds=ttft,
        tpot_seconds=tpot,
        throughput_tokens_per_second=throughput,
        peak_ram_mb=monitor.peak_ram_mb,
        peak_vram_mb=monitor.peak_vram_mb,
        total_runtime_seconds=total_runtime,
        device=device,
        dtype=dtype,
        status="ok",
        error="",
        generated_text=generated_text,
        quality_notes="Manual review required; performance does not imply semantic quality.",
    )


def main() -> int:
    args = parse_args()
    output_name = args.output_name or args.experiment
    prompts = load_prompts(Path(args.prompts)) if args.prompts else load_prompts()
    metadata = {"hardware": hardware_summary(), "git_commit": git_commit(), "requested_device": args.device}
    try:
        device = resolve_device(args.device)
        kwargs, dtype = model_kwargs_for_experiment(args.experiment, device)
        tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=False)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        model = AutoModelForCausalLM.from_pretrained(args.model, trust_remote_code=False, **kwargs)
        if device == "cpu":
            model.to("cpu")
        model.eval()
        rows = [benchmark_prompt(model, tokenizer, args.model, output_name, dtype, device, row, args) for row in prompts]
    except Exception as exc:
        message = f"{output_name} could not run: {type(exc).__name__}: {exc}"
        write_failure(output_name, message, {"model": args.model, **metadata})
        print(message, file=sys.stderr)
        return 2

    json_path, csv_path = write_results(output_name, rows)
    print(f"Wrote {json_path}\nWrote {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
