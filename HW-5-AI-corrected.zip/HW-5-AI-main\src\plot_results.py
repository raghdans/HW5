from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parents[1] / "figures" / ".mplconfig"))
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from src.utils import FIGURES_DIR, RESULTS_DIR


METRICS = {
    "ttft_seconds": ("TTFT Comparison", "TTFT (seconds)", "ttft_comparison.png"),
    "tpot_seconds": ("TPOT / ITL Comparison", "TPOT (seconds/token)", "tpot_comparison.png"),
    "throughput_tokens_per_second": (
        "Throughput Comparison",
        "Output tokens / second",
        "throughput_comparison.png",
    ),
}


def load_result_rows() -> pd.DataFrame:
    frames = []
    current_results = {"cpu_baseline.csv", "gpu_baseline.csv", "airllm.csv"}
    for path in RESULTS_DIR.glob("*.csv"):
        if path.name not in current_results:
            continue
        try:
            frame = pd.read_csv(path)
        except pd.errors.EmptyDataError:
            continue
        required = {"experiment", "prompt_id"}
        if required.issubset(frame.columns):
            frames.append(frame)
    if not frames:
        raise SystemExit("No benchmark CSV files found in results/. Run experiments first.")
    return pd.concat(frames, ignore_index=True)


def bar_metric(df: pd.DataFrame, metric: str, title: str, ylabel: str, filename: str) -> None:
    clean = df[df.get("status", "ok").eq("ok")].copy()
    clean[metric] = pd.to_numeric(clean[metric], errors="coerce")
    grouped = clean.groupby("experiment", as_index=False)[metric].mean().dropna()
    if grouped.empty:
        print(f"Skipping {metric}: no numeric successful rows.")
        return
    ax = grouped.plot(kind="bar", x="experiment", y=metric, legend=False, color="#356f8c")
    ax.set_title(title)
    ax.set_xlabel("Experiment")
    ax.set_ylabel(ylabel)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / filename, dpi=160)
    plt.close()


def memory_plot(df: pd.DataFrame) -> None:
    clean = df[df.get("status", "ok").eq("ok")].copy()
    for metric in ["peak_ram_mb", "peak_vram_mb"]:
        clean[metric] = pd.to_numeric(clean.get(metric), errors="coerce")
    grouped = clean.groupby("experiment", as_index=False)[["peak_ram_mb", "peak_vram_mb"]].mean()
    if grouped.empty:
        return
    ax = grouped.plot(kind="bar", x="experiment", y=["peak_ram_mb", "peak_vram_mb"], color=["#486b3d", "#9b5d2e"])
    ax.set_title("RAM / VRAM Usage Comparison")
    ax.set_xlabel("Experiment")
    ax.set_ylabel("MB")
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "memory_comparison.png", dpi=160)
    plt.close()


def main() -> int:
    FIGURES_DIR.mkdir(exist_ok=True)
    df = load_result_rows()
    for metric, (title, ylabel, filename) in METRICS.items():
        if metric in df.columns:
            bar_metric(df, metric, title, ylabel, filename)
    memory_plot(df)
    print(f"Wrote benchmark plots to {FIGURES_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
