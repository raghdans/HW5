from __future__ import annotations

import argparse
import csv

from src.utils import FIGURES_DIR, RESULTS_DIR


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compare on-prem LLM cost against API cost.")
    parser.add_argument("--hardware-cost-usd", type=float, default=1800)
    parser.add_argument("--electricity-usd-kwh", type=float, default=0.22)
    parser.add_argument("--hardware-lifetime-months", type=int, default=36)
    parser.add_argument("--power-watts", type=float, default=350)
    parser.add_argument("--api-input-usd-per-1m", type=float, default=0.15)
    parser.add_argument("--api-output-usd-per-1m", type=float, default=0.60)
    parser.add_argument("--output-share", type=float, default=0.35, help="Fraction of total tokens that are output tokens.")
    parser.add_argument("--min-monthly-tokens", type=int, default=1_000_000)
    parser.add_argument("--max-monthly-tokens", type=int, default=500_000_000)
    parser.add_argument("--points", type=int, default=80)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    RESULTS_DIR.mkdir(exist_ok=True)
    FIGURES_DIR.mkdir(exist_ok=True)

    monthly_hw = args.hardware_cost_usd / args.hardware_lifetime_months
    monthly_electricity = (args.power_watts / 1000) * 24 * 30 * args.electricity_usd_kwh
    on_prem_monthly = monthly_hw + monthly_electricity

    rows = []
    blended_api_usd_per_token = (
        (1 - args.output_share) * args.api_input_usd_per_1m
        + args.output_share * args.api_output_usd_per_1m
    ) / 1_000_000
    break_even_tokens = (
        round(on_prem_monthly / blended_api_usd_per_token)
        if blended_api_usd_per_token > 0
        else None
    )
    for i in range(args.points):
        monthly_tokens = round(
            args.min_monthly_tokens
            + i * (args.max_monthly_tokens - args.min_monthly_tokens) / max(args.points - 1, 1)
        )
        output_tokens = monthly_tokens * args.output_share
        input_tokens = monthly_tokens - output_tokens
        api_cost = (input_tokens / 1_000_000 * args.api_input_usd_per_1m) + (
            output_tokens / 1_000_000 * args.api_output_usd_per_1m
        )
        rows.append(
            {
                "monthly_tokens": monthly_tokens,
                "api_cost_usd": api_cost,
                "on_prem_cost_usd": on_prem_monthly,
                "api_minus_on_prem_usd": api_cost - on_prem_monthly,
            }
        )

    with (RESULTS_DIR / "economic_analysis.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    assumptions = [
        {"assumption": "hardware_cost_usd", "value": args.hardware_cost_usd},
        {"assumption": "electricity_usd_kwh", "value": args.electricity_usd_kwh},
        {"assumption": "hardware_lifetime_months", "value": args.hardware_lifetime_months},
        {"assumption": "power_watts", "value": args.power_watts},
        {"assumption": "api_input_usd_per_1m", "value": args.api_input_usd_per_1m},
        {"assumption": "api_output_usd_per_1m", "value": args.api_output_usd_per_1m},
        {"assumption": "output_share", "value": args.output_share},
        {"assumption": "break_even_monthly_tokens", "value": break_even_tokens or "not reached"},
    ]
    with (RESULTS_DIR / "economic_assumptions.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["assumption", "value"])
        writer.writeheader()
        writer.writerows(assumptions)

    try:
        import os

        os.environ.setdefault("MPLCONFIGDIR", str(FIGURES_DIR / ".mplconfig"))
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as exc:
        svg_path = FIGURES_DIR / "cost_comparison_break_even.svg"
        write_svg_fallback(rows, on_prem_monthly, break_even_tokens, svg_path)
        print(f"matplotlib is not installed: {exc}")
        print(f"Wrote fallback SVG graph to {svg_path}")
        return 0

    xs = [row["monthly_tokens"] for row in rows]
    api_ys = [row["api_cost_usd"] for row in rows]
    onprem_ys = [row["on_prem_cost_usd"] for row in rows]
    _, ax = plt.subplots()
    ax.plot(xs, api_ys, label="API", color="#8c3d52")
    ax.plot(xs, onprem_ys, label="On-Prem", color="#2f6f62")
    ax.set_title("On-Prem vs API Monthly Cost")
    ax.set_xlabel("Monthly tokens")
    ax.set_ylabel("USD / month")
    ax.grid(alpha=0.3)
    ax.legend()
    if break_even_tokens:
        ax.axvline(break_even_tokens, color="#444444", linestyle="--", linewidth=1)
        ax.text(break_even_tokens, on_prem_monthly, f" break-even: {break_even_tokens:,}", va="bottom")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "cost_comparison_break_even.png", dpi=160)
    plt.close()
    print(f"Wrote {RESULTS_DIR / 'economic_analysis.csv'}")
    print(f"Wrote {FIGURES_DIR / 'cost_comparison_break_even.png'}")
    return 0


def write_svg_fallback(rows: list[dict], on_prem_monthly: float, break_even_tokens: int | None, path) -> None:
    width, height = 900, 520
    margin_left, margin_bottom, margin_top, margin_right = 90, 70, 55, 35
    plot_w = width - margin_left - margin_right
    plot_h = height - margin_top - margin_bottom
    max_x = max(row["monthly_tokens"] for row in rows)
    max_y = max(max(row["api_cost_usd"] for row in rows), on_prem_monthly) * 1.1

    def x_scale(value: float) -> float:
        return margin_left + (value / max_x) * plot_w

    def y_scale(value: float) -> float:
        return margin_top + plot_h - (value / max_y) * plot_h

    api_points = " ".join(f"{x_scale(r['monthly_tokens']):.1f},{y_scale(r['api_cost_usd']):.1f}" for r in rows)
    onprem_y = y_scale(on_prem_monthly)
    break_even_line = ""
    if break_even_tokens:
        bx = x_scale(break_even_tokens)
        break_even_line = (
            f'<line x1="{bx:.1f}" y1="{margin_top}" x2="{bx:.1f}" y2="{height - margin_bottom}" '
            'stroke="#444" stroke-dasharray="5 5"/>'
            f'<text x="{bx + 6:.1f}" y="{onprem_y - 8:.1f}" font-size="13">break-even: {break_even_tokens:,}</text>'
        )

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  <rect width="100%" height="100%" fill="white"/>
  <text x="{width / 2}" y="30" text-anchor="middle" font-size="22" font-family="Arial">On-Prem vs API Monthly Cost</text>
  <line x1="{margin_left}" y1="{height - margin_bottom}" x2="{width - margin_right}" y2="{height - margin_bottom}" stroke="#222"/>
  <line x1="{margin_left}" y1="{margin_top}" x2="{margin_left}" y2="{height - margin_bottom}" stroke="#222"/>
  <polyline fill="none" stroke="#8c3d52" stroke-width="3" points="{api_points}"/>
  <line x1="{margin_left}" y1="{onprem_y:.1f}" x2="{width - margin_right}" y2="{onprem_y:.1f}" stroke="#2f6f62" stroke-width="3"/>
  {break_even_line}
  <text x="{width / 2}" y="{height - 22}" text-anchor="middle" font-size="15" font-family="Arial">Monthly tokens</text>
  <text transform="translate(24 {height / 2}) rotate(-90)" text-anchor="middle" font-size="15" font-family="Arial">USD / month</text>
  <text x="{width - 210}" y="72" font-size="14" fill="#8c3d52" font-family="Arial">API</text>
  <text x="{width - 210}" y="94" font-size="14" fill="#2f6f62" font-family="Arial">On-Prem</text>
  <text x="{margin_left}" y="{height - margin_bottom + 24}" font-size="12" font-family="Arial">0</text>
  <text x="{width - margin_right - 120}" y="{height - margin_bottom + 24}" font-size="12" font-family="Arial">{max_x:,}</text>
  <text x="38" y="{margin_top + 5}" font-size="12" font-family="Arial">${max_y:.0f}</text>
  <text x="38" y="{height - margin_bottom}" font-size="12" font-family="Arial">$0</text>
</svg>
"""
    path.write_text(svg, encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
