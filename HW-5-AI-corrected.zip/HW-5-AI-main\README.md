# HW5 - Local LLM Inference with Ollama, Hugging Face and AirLLM

## Goal

This repository implements the practical task from lecture L08:

1. select a Hugging Face model;
2. verify basic local inference with Ollama;
3. document why an unquantized large-model baseline does not fit the available RAM/VRAM;
4. run that large model with AirLLM layer streaming;
5. compare response time, runtime, RAM and VRAM without inventing unavailable measurements.

The small CPU reference is `TinyLlama/TinyLlama-1.1B-Chat-v1.0`. The large experiment uses
`Qwen/Qwen2.5-7B-Instruct`, a public model from a family supported by AirLLM. The models are
different on purpose: an 8 GB machine cannot safely load the 7.62B FP32 baseline. The comparison
table therefore includes `model_id` and `status`; it must not be interpreted as an apples-to-apples
speedup when the large baseline is unavailable.

## What was fixed

- `src/airllm_experiment.py` now performs real `AutoModel.from_pretrained(...)` and generation.
- AirLLM defaults to CPU and a 7B model; it saves success metrics or an explicit failure reason.
- `src/ollama_experiment.py` performs a real `ollama run` smoke test.
- Hugging Face TTFT is measured from generated token IDs, not buffered text chunks.
- Output tokens are sliced directly from returned IDs, so `max_new_tokens=64` cannot become 65
  through decode/re-encode drift.
- CPU and GPU outputs use separate names and no longer overwrite one another.
- failed runs return a non-zero exit code.
- the economic break-even is calculated analytically instead of selecting a coarse grid point.
- comparison output distinguishes `ok`, `failed`, and `not_run`.

## Installation

Use Python 3.10-3.12 in a virtual environment. AirLLM splits the original checkpoint into
layer-wise files on the first run, so reserve substantially more disk space than the model download.

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install --upgrade pip
.venv\Scripts\python -m pip install -r requirements.txt
```

Install Ollama separately, then pull the smoke-test model:

```powershell
ollama pull tinyllama
```

Do not commit a Hugging Face token. Set `HF_TOKEN` in the environment only if a gated model is used.

## Run the complete pipeline

```powershell
.venv\Scripts\python run_assignment.py
```

Useful constrained runs:

```powershell
# No CUDA machine
.venv\Scripts\python run_assignment.py --skip-gpu

# Validate code and small baseline before the large download
.venv\Scripts\python run_assignment.py --skip-gpu --skip-airllm
```

The complete AirLLM run can be launched directly:

```powershell
.venv\Scripts\python -m src.airllm_experiment `
  --model Qwen/Qwen2.5-7B-Instruct `
  --device cpu `
  --max-new-tokens 16 `
  --layer-cache D:\airllm-layers
```

On a CUDA machine, run the same large-model baseline separately:

```powershell
.venv\Scripts\python -m src.benchmark_hf `
  --model Qwen/Qwen2.5-7B-Instruct `
  --device cuda `
  --output-name gpu_baseline `
  --max-new-tokens 16
```

## Results and interpretation

Every experiment writes JSON/CSV under `results/`. Run:

```powershell
.venv\Scripts\python -m src.build_comparison
.venv\Scripts\python -m src.plot_results
```

`results/comparison.md` is the grading table. A backend with no hardware or missing software must
remain `failed`/`not_run`; zero is not a valid latency or memory measurement.

### Measured run (3 July 2026)

The corrected code was executed on a Windows CPU-only machine with 15.4 GiB RAM. These are measured
values, not estimates:

| Run | Model | Result | TTFT | Throughput | Peak RAM | Runtime |
|---|---|---|---:|---:|---:|---:|
| Ollama smoke test | TinyLlama | success (`Ready!`) | - | - | - | 1.017 s |
| Hugging Face CPU reference (3 prompts, mean) | TinyLlama 1.1B | success | 1.091 s | 3.501 tok/s | 4596 MB | 4.575 s |
| Large FP32 capacity check | Qwen2.5 7B | unsafe to load | - | - | estimated 34.06 GiB | - |
| AirLLM CPU smoke test (2 output tokens) | Qwen2.5 7B | success (`Ready`) | 24.499 s | 0.0507 tok/s | 1427 MB | 39.460 s |
| CUDA baseline | Qwen2.5 7B | unavailable | - | - | - | - |

The AirLLM and TinyLlama rows use different models and output lengths, so they demonstrate the
memory/latency trade-off and feasibility rather than a controlled speedup claim. The important
result is that the 7B FP32 baseline was estimated at 34.06 GiB while AirLLM completed generation with
about 1.43 GiB process RSS by streaming the 31 saved layers.

The included historical `baseline.json` and `baseline.csv` came from the original CPU run. Rerun the
corrected pipeline to produce `cpu_baseline.*`; the old TTFT values used text-chunk timing and should
not be mixed with the corrected measurements. The original PNG charts are retained under
`figures/legacy/` for provenance and are not corrected comparison figures.

### Metric definitions

- **TTFT**: elapsed time until the first generated token. AirLLM lacks a token-stream callback, so
  its TTFT is a separate one-token generation and is clearly labelled as such.
- **TPOT**: `(full runtime - TTFT) / (output_tokens - 1)` for the Hugging Face
  token-streamed run. AirLLM TPOT is left blank because its TTFT probe is a separate call with a
  potentially different cache state.
- **Throughput**: exact returned output-token count divided by full generation runtime.
- **Peak RAM**: peak resident memory of the benchmark Python process while generating. It does not
  include an already-running Ollama service.
- **Peak VRAM**: PyTorch peak reserved CUDA memory when CUDA is available.

## Expected hardware conclusion

At FP32, 7.62B weights alone require about 28.4 GiB. With a conservative 20% runtime overhead, the
estimate is about 34.1 GiB before considering all temporary allocations. `src.capacity_check` records
the formula and the available RAM at run time. On an 8 GB laptop, skipping a forced OOM is safer and
more reproducible than crashing the operating system.

AirLLM trades memory for latency by loading model layers sequentially. A successful AirLLM run proves
feasibility, not acceleration. The expected result is lower peak memory and much higher latency due to
disk/RAM traffic.

## Reproducibility checklist

- [x] `results/ollama.json` has `status: ok`.
- [x] `results/large_model_capacity_check.json` records the large baseline capacity decision.
- [x] `results/airllm.json` has a successful Qwen2.5-7B CPU row.
- [x] GPU result contains the exact `CUDA ... not available` reason.
- [x] `results/comparison.md` contains no fabricated zeros.
- [x] smoke-test answers were manually inspected (`Ready!` and `Ready`).

## Sources

- AirLLM project and current `AutoModel` usage: https://github.com/lyogavin/airllm
- AirLLM package: https://pypi.org/project/airllm/
- Hugging Face Transformers: https://huggingface.co/docs/transformers/
- Ollama: https://ollama.com/
