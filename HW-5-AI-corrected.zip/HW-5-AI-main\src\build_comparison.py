from __future__ import annotations

import csv
import json
from pathlib import Path

from src.utils import RESULTS_DIR


ORDER = ["cpu_baseline", "gpu_baseline", "airllm"]


def summarize(name: str) -> dict[str, object]:
    path = RESULTS_DIR / f"{name}.json"
    if not path.exists():
        return {"experiment": name, "model_id": "", "status": "not_run", "device": "", "ttft_s": "", "tpot_s": "", "tokens_s": "", "ram_mb": "", "vram_mb": "", "runtime_s": "", "note": "result file missing"}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        return {"experiment": name, "model_id": payload.get("extra", {}).get("model", payload.get("model_id", "")), "status": payload.get("status", "failed"), "device": "", "ttft_s": "", "tpot_s": "", "tokens_s": "", "ram_mb": "", "vram_mb": "", "runtime_s": "", "note": payload.get("error", "")}
    ok = [row for row in payload if row.get("status") == "ok"]
    if not ok:
        return {"experiment": name, "model_id": "", "status": "failed", "device": "", "ttft_s": "", "tpot_s": "", "tokens_s": "", "ram_mb": "", "vram_mb": "", "runtime_s": "", "note": "no successful rows"}

    def average(key: str):
        values = [float(row[key]) for row in ok if row.get(key) is not None]
        return round(sum(values) / len(values), 4) if values else ""

    return {
        "experiment": name,
        "model_id": ok[0].get("model_id", ""),
        "status": "ok",
        "device": ok[0].get("device", ""),
        "ttft_s": average("ttft_seconds"),
        "tpot_s": average("tpot_seconds"),
        "tokens_s": average("throughput_tokens_per_second"),
        "ram_mb": average("peak_ram_mb"),
        "vram_mb": average("peak_vram_mb"),
        "runtime_s": average("total_runtime_seconds"),
        "note": "",
    }


def main() -> int:
    rows = [summarize(name) for name in ORDER]
    csv_path = RESULTS_DIR / "comparison.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    md_path = RESULTS_DIR / "comparison.md"
    headers = list(rows[0])
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    lines.extend("| " + " | ".join(str(row[h]).replace("|", "\\|") for h in headers) + " |" for row in rows)
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {csv_path} and {md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
