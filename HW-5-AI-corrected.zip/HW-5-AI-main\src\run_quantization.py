from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from src.utils import RESULTS_DIR, write_failure


def run_variant(variant: str, model: str, max_new_tokens: int) -> None:
    command = [
        sys.executable,
        "-m",
        "src.benchmark_hf",
        "--experiment",
        variant,
        "--model",
        model,
        "--max-new-tokens",
        str(max_new_tokens),
    ]
    try:
        subprocess.run(command, check=True, cwd=Path(__file__).resolve().parents[1])
    except subprocess.CalledProcessError as exc:
        write_failure(variant, f"Experiment {variant} failed with exit code {exc.returncode}.")


def main() -> int:
    model = sys.argv[1] if len(sys.argv) > 1 else "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
    max_new_tokens = int(sys.argv[2]) if len(sys.argv) > 2 else 64
    RESULTS_DIR.mkdir(exist_ok=True)
    for variant in ["fp16", "int8", "int4"]:
        run_variant(variant, model, max_new_tokens)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
