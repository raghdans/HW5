from __future__ import annotations

import argparse
import subprocess
import sys


SMALL_MODEL = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
LARGE_MODEL = "Qwen/Qwen2.5-7B-Instruct"


def run(label: str, args: list[str]) -> int:
    print(f"\n=== {label} ===", flush=True)
    completed = subprocess.run([sys.executable, *args], check=False)
    if completed.returncode:
        print(f"{label}: unavailable/failed (exit {completed.returncode}); result file records the reason.")
    return completed.returncode


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the HW5 experiment pipeline.")
    parser.add_argument("--skip-ollama", action="store_true")
    parser.add_argument("--skip-gpu", action="store_true")
    parser.add_argument("--skip-airllm", action="store_true")
    parser.add_argument("--max-new-tokens", type=int, default=16)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not args.skip_ollama:
        run("Ollama smoke test", ["-m", "src.ollama_experiment", "--model", "tinyllama"])

    run("Small CPU reference", [
        "-m", "src.benchmark_hf", "--model", SMALL_MODEL, "--device", "cpu",
        "--output-name", "cpu_baseline", "--max-new-tokens", str(args.max_new_tokens),
    ])
    run("Large-model RAM capacity check", [
        "-m", "src.capacity_check", "--model", LARGE_MODEL, "--parameters-billions", "7.62",
    ])

    if not args.skip_gpu:
        run("Large GPU baseline", [
            "-m", "src.benchmark_hf", "--model", LARGE_MODEL, "--device", "cuda",
            "--output-name", "gpu_baseline", "--max-new-tokens", str(args.max_new_tokens),
        ])
    if not args.skip_airllm:
        run("Large AirLLM CPU run", [
            "-m", "src.airllm_experiment", "--model", LARGE_MODEL, "--device", "cpu",
            "--output-name", "airllm", "--max-new-tokens", str(args.max_new_tokens),
        ])

    run("Comparison table", ["-m", "src.build_comparison"])
    run("Plots", ["-m", "src.plot_results"])
    print("\nPipeline finished. A failed/unavailable backend is evidence only when its result JSON contains the reason.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
