from __future__ import annotations

import csv
import json
import platform
import subprocess
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

try:
    import psutil
except Exception:
    psutil = None


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / "results"
FIGURES_DIR = PROJECT_ROOT / "figures"
PROMPTS_PATH = PROJECT_ROOT / "experiments" / "prompts.json"


@dataclass
class BenchmarkResult:
    experiment: str
    model_id: str
    prompt_id: str
    prompt_chars: int
    input_tokens: int
    output_tokens: int
    ttft_seconds: float | None
    tpot_seconds: float | None
    throughput_tokens_per_second: float | None
    peak_ram_mb: float
    peak_vram_mb: float | None
    total_runtime_seconds: float
    device: str
    dtype: str
    status: str
    error: str
    generated_text: str
    quality_notes: str


class MemoryMonitor:
    """Samples process RAM and CUDA VRAM while generation is running."""

    def __init__(self, interval_seconds: float = 0.05) -> None:
        self.interval_seconds = interval_seconds
        self.process = psutil.Process() if psutil else None
        self.peak_ram_mb = 0.0
        self.peak_vram_mb: float | None = None
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._sample_loop, daemon=True)

    def __enter__(self) -> "MemoryMonitor":
        self._thread.start()
        return self

    def __exit__(self, *_: object) -> None:
        self._stop.set()
        self._thread.join(timeout=2)
        self._sample_once()

    def _sample_loop(self) -> None:
        while not self._stop.is_set():
            self._sample_once()
            time.sleep(self.interval_seconds)

    def _sample_once(self) -> None:
        if self.process:
            rss_mb = self.process.memory_info().rss / (1024 * 1024)
            self.peak_ram_mb = max(self.peak_ram_mb, rss_mb)
        try:
            import torch

            if torch.cuda.is_available():
                current = torch.cuda.max_memory_reserved() / (1024 * 1024)
                self.peak_vram_mb = max(self.peak_vram_mb or 0.0, current)
        except Exception:
            pass


def load_prompts(path: Path = PROMPTS_PATH) -> list[dict[str, str]]:
    return json.loads(path.read_text(encoding="utf-8"))


def ensure_dirs() -> None:
    RESULTS_DIR.mkdir(exist_ok=True)
    FIGURES_DIR.mkdir(exist_ok=True)


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def write_results(experiment: str, rows: Iterable[BenchmarkResult]) -> tuple[Path, Path]:
    ensure_dirs()
    materialized = [asdict(row) for row in rows]
    json_path = RESULTS_DIR / f"{experiment}.json"
    csv_path = RESULTS_DIR / f"{experiment}.csv"
    write_json(json_path, materialized)
    if materialized:
        with csv_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(materialized[0].keys()))
            writer.writeheader()
            writer.writerows(materialized)
    else:
        csv_path.write_text("", encoding="utf-8")
    return json_path, csv_path


def write_failure(experiment: str, message: str, extra: dict[str, Any] | None = None) -> tuple[Path, Path]:
    payload = {
        "experiment": experiment,
        "status": "failed",
        "error": message,
        "extra": extra or {},
        "hardware": hardware_summary(),
    }
    write_json(RESULTS_DIR / f"{experiment}.json", payload)
    csv_path = RESULTS_DIR / f"{experiment}.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["experiment", "status", "error"])
        writer.writeheader()
        writer.writerow({"experiment": experiment, "status": "failed", "error": message})
    return RESULTS_DIR / f"{experiment}.json", csv_path


def hardware_summary() -> dict[str, Any]:
    summary: dict[str, Any] = {
        "platform": platform.platform(),
        "python": platform.python_version(),
        "cpu": platform.processor() or "unknown",
        "ram_gb": round(psutil.virtual_memory().total / (1024**3), 2) if psutil else "psutil-not-installed",
    }
    try:
        import torch

        summary["torch"] = torch.__version__
        summary["cuda_available"] = torch.cuda.is_available()
        if torch.cuda.is_available():
            summary["cuda_device"] = torch.cuda.get_device_name(0)
            summary["cuda_device_count"] = torch.cuda.device_count()
            summary["cuda_total_vram_gb"] = round(
                torch.cuda.get_device_properties(0).total_memory / (1024**3), 2
            )
    except Exception as exc:
        summary["torch_error"] = str(exc)
    return summary


def git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=PROJECT_ROOT,
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
    except Exception:
        return "not-a-git-repo"
